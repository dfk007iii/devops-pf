<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\AvailableSource;
use Illuminate\Support\Facades\File;

class AvailableSourceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

    }
}
